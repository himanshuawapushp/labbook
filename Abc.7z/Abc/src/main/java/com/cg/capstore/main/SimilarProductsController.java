package com.cg.capstore.main;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;



@Controller
public class SimilarProductsController {
	
	
	
	@PersistenceContext
	EntityManager entitymanager;
	
	@RequestMapping(value="/")
	public String SimilarProductsInterface() {
		
		String cat1="Clothes"; 
		
		Query query = entitymanager.createQuery("select p.name from Product p where p.prodCategory =:cat").setParameter("cat", cat1);
				List<String> list = query.getResultList();
		System.out.println(list);
		
		return "/pages/index.jsp";
	}
}
