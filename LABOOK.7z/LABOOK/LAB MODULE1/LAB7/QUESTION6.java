LAB-7 QUESTION-6
-----------------------



package ques7_6.com.cg.eis.bean;

public class Employee {
	private int id;
	private String name;
	private double salary;
	private String designation;
	private String insuranceScheme;
	
	public Employee(String name, String designation) {
		super();
//		this.id = id;
		this.name = name;
//		this.salary = salary;
		this.designation = designation;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public String getInsuranceScheme() {
		return insuranceScheme;
	}

	public void setInsuranceScheme(String insuranceScheme) {
		this.insuranceScheme = insuranceScheme;
	}
	
}

--------------------------------------------------------------------------------

package ques7_6.com.cg.eis.pl;

import java.util.*;

import ques7_6.com.cg.eis.bean.Employee;
import ques7_6.com.cg.eis.service.EmployeeService;

public class Main {

	public static void main(String[] args) {
		

		
		Scanner scan = new Scanner(System.in);
		
		
		
//		System.out.println(name + salary + designation + insuranceScheme);

		EmployeeService empServ = new EmployeeService();
		
		char flag = 'T';
		while(flag == 'T') {
			System.out.println("Enter Choice: ");
			int ch = scan.nextInt();
			switch(ch) {
				case 1: 
					System.out.print("Salary : ");
					double salary = scan.nextDouble();
					System.out.print("Employee Name: ");		
					String name = scan.next();
	//			scan.next();
					System.out.print("Insurance Scheme: ");
					String insuranceScheme = scan.next();
	//			scan.next();
					Employee emp = new Employee(name, insuranceScheme);
					empServ.addEmployee(emp);
					break;
				
				case 2: 
					System.out.println("Enter Insurance Scheme: ");
//					scan.next();
					String insScheme = scan.next();
					empServ.showDetails(insScheme);
					break; 
					
				case 3: 
					System.out.println("Enter Id: ");
					empServ.deleteEmployee(scan.nextInt());
					break;
//		case 4: sort(empList);
//		break;
				case 5: flag = 'F';
				break;
				
			}			
		}
		
		

	}

}

------------------------------------------------------------------------------------------------

package ques7_6.com.cg.eis.service;

import java.util.HashMap;
import java.util.Map.Entry;
import java.util.*;

import ques7_6.com.cg.eis.bean.Employee;

public class EmployeeService {
	static int key = 101;
	Map<Integer, Employee> map = new HashMap<>();

	public void addEmployee(Employee emp) {
		map.put(key, emp);
		key++;
		
		System.out.println("Employee successfully added!!!");
	}
	
	public void showDetails(String insuranceScheme) {
		for(Entry<Integer, Employee> entry:map.entrySet()){    
//	        int key = entry.getKey();  
//	        Employee emp = entry.getValue();  
//	        System.out.println(emp.getId());
	        System.out.println("Details: \n-----------------\n");  
	        if(entry.getValue().getInsuranceScheme().equals(insuranceScheme)) {
	        	System.out.println(entry.getValue().getId() + entry.getValue().getName() + entry.getValue().getSalary() + entry.getValue().getDesignation()+"\n");   	        	
	        }
	    }  
	}
	
	public void deleteEmployee(int id) {
//		map.remove(id);
		System.out.println("Map after removed: ");
		System.out.println("Details: \n-----------------\n");  
		for(Entry<Integer, Employee> entry:map.entrySet()){    
//	        int key = entry.getKey();  
//	        Employee emp = entry.getValue();  
	        System.out.println(entry.getKey() + entry.getValue().getName() + entry.getValue().getSalary() + entry.getValue().getDesignation()+"\n");   	        	
	    }  		
	}
		
}

----------------------------------------------------------------------------------------------------------------------

package ques7_6.com.cg.eis.service;

public class Service {

}