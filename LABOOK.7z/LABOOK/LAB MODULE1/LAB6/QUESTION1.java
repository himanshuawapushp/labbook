LAB-6 QUESTION-1
------------------


package com.capg.pkg6;

public class Person1 {

	// TODO Auto-generated method stub
	private String firstName;
	private String lastName;
	private char gender;

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Person1(String firstName, String lastName, char gender) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
	}

	public char getGender() {
		return gender;
	}

	public void setGender(char gender) {
		this.gender = gender;
	}
}

----------------------------------------------------------------------------------------

package com.capg.pkg6;



public class Personmain {
	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub

		Person1 obj = new Person1("himanshu", "mishra", 'm');
		System.out.println("first name:" + obj.getFirstName());
		System.out.println("last name:" + obj.getLastName());
		System.out.println("gender" + obj.getGender());
		obj.setFirstName("hims");
		obj.setLastName("mishra");
		obj.setGender('m');
		System.out.println("first name:" + obj.getFirstName());
		System.out.println("last name:" + obj.getLastName());
		System.out.println("gender" + obj.getGender());
		try {
			if (obj.getFirstName().isEmpty() || obj.getLastName().isEmpty()) {
			throw new Exception();
			}
		} catch (Exception e) {
			System.out.println("Name Should Not be blank");
		}
	}

}