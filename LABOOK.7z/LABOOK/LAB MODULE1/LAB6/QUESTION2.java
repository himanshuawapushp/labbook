LAB-6 QUESTION-2
-----------------



package com.capg.pkg6;

import com.capg.pkg62.Person;

public class Account {
	private long accnum;
	private double balance;
	Person accholder;
	public Account(long accnum, double balance, Person accholder) {
		super();
		this.accnum = accnum;
		this.balance = balance;
		this.accholder = accholder;
		if(this.balance<500)
		{
			System.out.println("balance should be greater than 500");
		}
	}
	public long getAccnum() {
		return accnum;
	}
	public void setAccnum(long accnum) {
		this.accnum = accnum;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public Person getAccholder() {
		return accholder;
	}
	public void setAccholder(Person accholder) {
		this.accholder = accholder;
	}
	public void deposite(double balance) {
		this.balance+=balance;
		System.out.println("balane in account after deposite is::"+this.balance);
	}
	public void withdraw(double balance)
	{
		this.balance-=balance;
		System.out.println("balane in account after withdraw is::"+this.balance);
	}
	@Override
	public String toString() {
		return "Account [accnum=" + accnum + ", balance=" + balance + ", accholder=" + accholder.getName() + "]";
	}
	
}

----------------------------------------------------------------------------------------------------------------------

package com.capg.pkg6;

import java.util.Random;

import com.capg.pkg6.Account;
import com.capg.pkg6.Person;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Person p1 = new Person("Smith", 22.0f);
		Person p2 = new Person("Kathy", 12.0f);
		try {
			if (p1.getAge() < 15.0f || p2.getAge() < 15.0f) {
				throw new Exception("age should be greater than 15");
				//System.out.println("age should be greater than 15");
			}
			Random rand = new Random();
			int x = rand.nextInt(10000);
			int y = rand.nextInt(10000);
			if (x == y) {
				while (x == y) {
					y = rand.nextInt(10000);
				}
			}
			Account a1 = new Account(x, 2000, p1);
			Account a2 = new Account(y, 2000, p2);
			System.out.println(a1.toString());
			System.out.println(a2.toString());
			a1.deposite(2000);
			a2.withdraw(2000);
			System.out.println(a1.toString());
			System.out.println(a2.toString());
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}
}

----------------------------------------------------------------------------------------------------------

package com.capg.pkg6;



public class Person {
	private String name;
	private float age;

	public Person(String name, float age) {
		this.name = name;
		this.age = age;
		
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public float getAge() {
		return age;
	}
	public void setAge(float age) {
		this.age = age;
	
}
}