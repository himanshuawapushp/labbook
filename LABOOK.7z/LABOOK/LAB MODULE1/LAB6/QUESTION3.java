LAB-6 QUESTION-3
---------------------



package com.cg.eis.bean;

public class Employee {
	private int id;
	private String name;
	private int salary;
	private String designation;
	private String insurance;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public String getInsurance() {
		return insurance;
	}

	public void setInsurance(String insurance) {
		this.insurance = insurance;
	}

	public Employee(int id, String name, int salary, String designation, String insurance) {
		super();
		this.id = id;
		this.name = name;
		this.salary = salary;
		this.designation = designation;
		this.insurance = insurance;
	}
}

----------------------------------------------------------------------------------------------------

package com.cg.eis.exception;

public class EmployeeException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public EmployeeException(String str) {
		super(str);

	}
}

--------------------------------------------------------------------------------------------------------

package com.cg.eis.pl;

import com.cg.eis.bean.*;
import com.cg.eis.service.*;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Service s = new Service();
try {
	
		Employee e = s.setDetails();

		System.out.println("Salary is: " + e.getSalary());
		System.out.println("Employee name is: " + e.getName());
		System.out.println("Employee id is: " + e.getId());
		System.out.println("Employee designation is: " + e.getDesignation());
		System.out.println("Employee insurance scheme is: " + e.getInsurance());
		s.Insurance(e.getSalary(), e.getDesignation(), e);
		s.getDetails();
}
catch(Exception e){
	System.out.println(e.getMessage());
}
	}
}

----------------------------------------------------------------------------------------------

package com.cg.eis.service;

import com.cg.eis.bean.Employee;
import com.cg.eis.exception.EmployeeException;

public interface EmployeeService {
	public Employee setDetails() throws EmployeeException;

	public void Insurance(int salary, String designation, Employee e);

	public void getDetails();

}

-------------------------------------------------------------------------------------------------

package com.cg.eis.service;

import java.util.*;
import com.cg.eis.bean.Employee;
import com.cg.eis.exception.EmployeeException;

public class Service implements EmployeeService {
	Employee e;

	public Employee setDetails()throws EmployeeException {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the string");
		String str = sc.next();
		System.out.println("enter the emp id");
		int a = sc.nextInt();
		System.out.println("Enter the Salary");
		int b = sc.nextInt();
		System.out.println("Enter the Designation");
		String str1 = sc.next();
		System.out.println("Enter the insurence");
		String str2 = sc.next();
		e = new Employee(a, str, b, str1, str2);
		sc.close();
		if(b<3000)
		{
			throw new EmployeeException("salary Should Be Greater then 3000");
		}

	
		return e;
	
		}

	public void Insurance(int salary, String designation, Employee a) {
		if (designation.equals("System Associate") && (salary > 5000 && salary < 20000))
			a.setInsurance("C");
		else if (designation.equals("Programmer") && (salary >= 20000 && salary < 40000))
			a.setInsurance("B");
		else if (designation.equals("Manager") && (salary >= 40000))
			a.setInsurance("A");
		else if (designation.equals("Clerk") && (salary < 5000))
			a.setInsurance("No");

	}

	public void getDetails() {
		System.out.println("Salary is: " + e.getSalary());
		System.out.println("Employee name is: " + e.getName());
		System.out.println("Employee id is: " + e.getId());
		System.out.println("Employee designation is: " + e.getDesignation());
		System.out.println("Employee insurance scheme is: " + e.getInsurance());
	}

}