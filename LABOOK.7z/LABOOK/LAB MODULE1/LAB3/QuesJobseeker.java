LAB-3 QUESTION-7
-----------------



package com.capg.lab3;
import java.util.*;

public class QuesJobseeker {
	static Scanner sc=new Scanner(System.in);

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		checkJob();

	}
	
	private static void checkJob(){
		System.out.println("Enter user name to register:");
		String str=sc.nextLine();
		if(str.length()>=12){
			for(int i=0;i<str.length();i++){
				char c=str.charAt(i);
				if((c=='_')&&(str.charAt(i+1)=='j')&&(str.charAt(i+2)=='o')&&(str.charAt(i+3)=='b')){
					System.out.println("true");
				}
			}
		}
		else{
			
			System.out.println("false");
		}
	}
}
