LAB-3 QUESTION-1
-----------------



package com.capg.lab3;
import java.util.Scanner;

public class AcceptString {
	 static Scanner sc=new Scanner(System.in);
	 static String str=sc.nextLine();

	public static void main(String[] args) {
		acceptstring();
	}
	
	public static void acceptstring(){
		System.out.println("1. Add string to itself");
		System.out.println("2. Replace odd position with #");
		System.out.println("3. Remove duplicate character");
		System.out.println("4. Change odd character to upper case");
		//System.out.println("5. Exit");
		System.out.println("Enter your choice: ");
		int choice=sc.nextInt();
		
		//while(true){
			switch(choice){
			case 1:addstr();
			break;
			case 2:replace();
			break;
			case 3:removeduplicate();
			break;
			case 4:upperodd();
			break;
			default:System.out.println("Wrong choice");
			
			//}
		}
		
		
	}

	private static void upperodd() {
		String[] str5=str.split("");
		for(int i=0;i<str.length();i++){
			if(str5[i]!=null){
				if(i%2!=0){
					str5[i]=str5[i].toUpperCase();
				}
			}
		}
		for(int j=0;j<str.length();j++){
			System.out.print(str5[j]);
		}
	}

	private static void removeduplicate() {
		String[] str3=str.split("");
		for(int i=0;i<str.length();i++){
			if(str3[i]!=null){
				for(int j=i+1;j<str.length();j++){
					if(str3[i].equals(str3[j])){
						str3[j]=null;
					}
				}
			}
		}
		for(int k=0;k<str.length();k++){
			if(str3[k]!=null){
			System.out.print(str3[k]);
		}}
	}

	private static void replace() {
		String[] str4=str.split("");
		for(int i=0;i<str.length();i++){
			if(str4[i]!=null){
				if(i%2!=0){
					str4[i]="#";
				}
			}
		}
		for(int j=1;j<str.length();j++){
			System.out.print(str4[j]);
		}
	}

	private static void addstr() {
		String str1=str;
		System.out.println(str+""+str1);
	}

}
