LAB-2 QUESTION-5
------------------




package com.capg.lab2;

import com.capg.lab2.quesEnum.Gender;

public class qesEnum2 {
	private String fname;
	private String lname;
	private String mobno;
	private Gender gender;
	
	
	
	public qesEnum2(String fname, String lname, String mobno, Gender m) {
		super();
		this.fname = fname;
		this.lname = lname;
		this.mobno = mobno;
		this.gender = m;
	}
	public Gender getGender() {
		return gender;
	}
	public void setGender(String gender) {
		gender = gender;
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public String getMobno() {
		return mobno;
	}
	public void setMobno(String mobno) {
		mobno = mobno;
	}
	

}
