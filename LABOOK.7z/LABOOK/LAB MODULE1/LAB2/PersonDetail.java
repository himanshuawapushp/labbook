LAB-2 QUESTION-1
----------------




package com.capg.lab2;

public class PersonDetail {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Person Detail");
		System.out.println("-----------------");
		System.out.println("First Name:Vaibhav");
		System.out.println("Last Name:Shukla");
		System.out.println("Gender:M");
		System.out.println("Age:21");
		System.out.println("Weight:53");

	}

}
