package com.cg.mpt.controller;

public class InvalidCustomerException extends RuntimeException{

}
