package com.cg.Exception;

public class InvalidCustomerException extends RuntimeException{

}
