package webdriver;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class WorkingWithForms {
	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver;
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\HIMANSMI\\Desktop\\Module 3\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("file:///C:/Users/HIMANSMI/Desktop/Module%203/WorkingWithForms.html");

		driver.findElement(By.id("txtUserName")).sendKeys("Him");
		Thread.sleep(1000);
		driver.findElement(By.name("txtPwd")).sendKeys("Awap");
		Thread.sleep(1000);
		driver.findElement(By.className("Format")).sendKeys("Awap");
		Thread.sleep(1000);
		driver.findElement(By.className("Format1")).sendKeys("Himanshu");
		Thread.sleep(1000);
		driver.findElement(By.id("txtLastName")).sendKeys("Mishra");
		Thread.sleep(1000);
		driver.findElement(By.cssSelector("input[value='Male']")).click();
		driver.findElement(By.name("DtOB")).sendKeys("20/12/1996");
		driver.findElement(By.name("Email")).sendKeys("him@gmail.com");
		driver.findElement(By.name("Address")).sendKeys("Varanasi");
		Select drpCity = new Select(driver.findElement(By.name("City")));
		drpCity.selectByIndex(1);
		driver.findElement(By.xpath(".//*[@id='txtPhone']")).sendKeys("9598526348");
		driver.findElement(By.cssSelector("input[value='Reading']")).click();
		driver.findElement(By.cssSelector("input[value='Movies']")).click();
		driver.findElement(By.id("myStyle")).click();


		// List<WebElement> element = driver.findElement(By.name("chkHobbies"));

	}
}
