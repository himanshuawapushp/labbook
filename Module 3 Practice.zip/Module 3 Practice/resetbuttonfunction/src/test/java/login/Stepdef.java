package login;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import pagebean.LoginPage;


public class Stepdef{
	private WebDriver driver;
	private LoginPage obj;
	@Given("^User is on hotel login page$")
	public void user_is_on_hotel_login_page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\HIMANSMI\\Desktop\\Module 3\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		obj = new LoginPage(driver);
		driver.get("file:///C:/Users/HIMANSMI/Desktop/Module%203/login.html");
	}
	
	@Then("^check the title of the page$")
	public void check_the_title_of_the_page() throws Throwable {
	 
	}

	@When("^user enters all valid data$")
	public void user_enters_all_valid_data() throws Throwable {
	   obj.setPffname("capgemini");  Thread.sleep(1000);
	   obj.setPass("capg1234");
	   driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);

	   obj.setPfbutton();
	}

	@Then("^navigate to welcome page$")
	public void navigate_to_welcome_page() throws Throwable {
		driver.navigate().to("file:///C:/Users/HIMANSMI/Desktop/Module%203/hotelbooking.html");
		driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
		Thread.sleep(1000);
		driver.close();
	}

	@When("^user leaves userName blank$")
	public void user_leaves_userName_blank() throws Throwable {
	    obj.setPffname(""); Thread.sleep(1000);
	}

	@When("^clicks the button$")
	public void clicks_the_button() throws Throwable {
	  obj.setPfbutton();
	}

	@Then("^display alert msg$")
	public void display_alert_msg() throws Throwable {
	   System.out.println(driver.findElement(By.id("userErrMsg")).getText());
	}

	@When("^user leaves password blank and clicks the button$")
	public void user_leaves_password_blank_and_clicks_the_button() throws Throwable {
		obj.setPffname("capgemini"); Thread.sleep(1000);
		obj.setPass("");  Thread.sleep(1000);
		obj.setPfbutton();
		System.out.println(driver.findElement(By.id("pwdErrMsg")).getText());
	}

	@When("^user enters incorrect userName or password and click the button$")
	public void user_enters_incorrect_userName_or_password_and_click_the_button() throws Throwable {
		obj.setPffname("Capgemini"); Thread.sleep(1000);
		obj.setPass("Himan");  Thread.sleep(1000);
		obj.setPfbutton();
	}
}
