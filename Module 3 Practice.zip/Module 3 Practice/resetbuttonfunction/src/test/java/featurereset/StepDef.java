package featurereset;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {
	@Given("^Open the Firefox and launch the Application$")
	public void open_the_Firefox_and_launch_the_Application() throws Throwable {
	    
	}

	@When("^Enter the Username and Password$")
	public void enter_the_Username_and_Password() throws Throwable {
	    
	}

	@Then("^Reset the credential$")
	public void reset_the_credential() throws Throwable {
	    
	}


}
