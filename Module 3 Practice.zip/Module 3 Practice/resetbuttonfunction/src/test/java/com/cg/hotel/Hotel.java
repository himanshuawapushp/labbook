package com.cg.hotel;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Hotel {
	static WebDriver driver;
	public static void main(String[] args) throws InterruptedException{
		//WebDriver driver;

		System.setProperty("webdriver.chrome.driver", "C:\\Users\\HIMANSMI\\Desktop\\Module 3\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("file:///C:/Users/HIMANSMI/Desktop/Module%203/hotelbooking.html");
		//Thread.sleep(1000);
		driver.findElement(By.id("txtFirstName")).sendKeys("");
		driver.findElement(By.id("btnPayment")).click();
		Thread.sleep(1000);
		alert();
		
		driver.findElement(By.id("txtFirstName")).sendKeys("Him");
		driver.findElement(By.id("txtLastName")).sendKeys("");
		driver.findElement(By.id("btnPayment")).click();
		Thread.sleep(1000);
		alert();
		
		driver.findElement(By.id("txtFirstName")).sendKeys("Himanshu");
		driver.findElement(By.id("txtLastName")).sendKeys("Mishra");
		driver.findElement(By.id("txtEmail")).sendKeys("");
		driver.findElement(By.id("btnPayment")).click();
		Thread.sleep(1000);
		alert();
		
		driver.findElement(By.id("txtFirstName")).sendKeys("Himanshu");
		driver.findElement(By.id("txtLastName")).sendKeys("Mishra");
		driver.findElement(By.id("txtEmail")).sendKeys("himanshu.mishra_cs15@gla.ac.in");
		driver.findElement(By.id("txtPhone")).sendKeys("");
		driver.findElement(By.id("btnPayment")).click();
		Thread.sleep(1000);
		alert();
		
		driver.findElement(By.id("txtFirstName")).sendKeys("Himanshu");
		driver.findElement(By.id("txtLastName")).sendKeys("Mishra");
		driver.findElement(By.id("txtEmail")).sendKeys("himanshu.mishra_cs15@gla.ac.in");
		driver.findElement(By.id("txtPhone")).sendKeys("9598526348");
		driver.findElement(By.cssSelector("input[pattern='[789][0-9]{9}']")).sendKeys("789");
		driver.findElement(By.xpath("html/body/div/div/form/table/tbody/tr[6]/td[2]/textarea")).sendKeys("pune");
		Select drpCity = new Select(driver.findElement(By.name("city")));
		drpCity.selectByIndex(2);
		driver.findElement(By.id("btnPayment")).click();
		Thread.sleep(1000);
		alert();
		
		driver.findElement(By.id("txtFirstName")).sendKeys("Himanshu");
		driver.findElement(By.id("txtLastName")).sendKeys("Mishra");
		driver.findElement(By.id("txtEmail")).sendKeys("himanshu.mishra_cs15@gla.ac.in");
		driver.findElement(By.id("txtPhone")).sendKeys("9598526349");
		driver.findElement(By.xpath("html/body/div/div/form/table/tbody/tr[6]/td[2]/textarea")).sendKeys("pune");
		Select drp1City = new Select(driver.findElement(By.name("state")));
		drp1City.selectByIndex(2);
		driver.findElement(By.id("btnPayment")).click();
		Thread.sleep(1000);
		alert();
		

		driver.findElement(By.id("txtFirstName")).sendKeys("Himanshu");
		driver.findElement(By.id("txtLastName")).sendKeys("Mishra");
		driver.findElement(By.id("txtEmail")).sendKeys("himanshu.mishra_cs15@gla.ac.in");
		driver.findElement(By.id("txtPhone")).sendKeys("9598526340");
		driver.findElement(By.xpath("html/body/div/div/form/table/tbody/tr[6]/td[2]/textarea")).sendKeys("pune");
		Select drp2City = new Select(driver.findElement(By.name("persons")));
		drp2City.selectByIndex(5);
		driver.findElement(By.id("btnPayment")).click();
		Thread.sleep(1000);
		alert();
		
		driver.findElement(By.id("txtFirstName")).sendKeys("Himanshu");
		driver.findElement(By.id("txtLastName")).sendKeys("Mishra");
		driver.findElement(By.id("txtEmail")).sendKeys("himanshu.mishra_cs15@gla.ac.in");
		driver.findElement(By.id("txtPhone")).sendKeys("9598526341");
		driver.findElement(By.xpath("html/body/div/div/form/table/tbody/tr[6]/td[2]/textarea")).sendKeys("pune");
		
		driver.findElement(By.id("btnPayment")).click();
		Thread.sleep(1000);
		alert();
		
		
		
		
	}
	public static void alert() {
		String alertmessage= driver.switchTo().alert().getText();
		System.out.println("The alert message is:"+ alertmessage);
		driver.switchTo().alert().accept();
		
		
	}

}
