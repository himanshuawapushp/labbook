package com.cg.alertbox;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class AlertBoxDemos {
	public static void main(String[] args) throws InterruptedException {
		WebDriver driver;

		System.setProperty("webdriver.chrome.driver", "C:\\Users\\HIMANSMI\\Desktop\\Module 3\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("C:\\Users\\HIMANSMI\\Desktop\\Module 3\\AlertBoxDemos.html");
		Thread.sleep(1000);
		driver.findElement(By.id("alert")).click();
		Thread.sleep(1000);
		Alert alert = driver.switchTo().alert();
		System.out.println("The alert message is:" + alert.getText());
		alert.accept();
		Thread.sleep(1000);
		
		driver.findElement(By.id("confirm")).click();
		Thread.sleep(1000);

		Alert confirm = driver.switchTo().alert();
		confirm.accept();
		Thread.sleep(1000);
		
		driver.findElement(By.id("confirm")).click();
		Thread.sleep(1000);
		confirm = driver.switchTo().alert();
		confirm.dismiss();
		Thread.sleep(1000);
		
		driver.findElement(By.id("prompt")).click();
		Thread.sleep(1000);
		Alert prompt = driver.switchTo().alert();
		String text = prompt.getText();
		System.out.println(text);
		prompt.sendKeys("himanshu");
		Thread.sleep(1000);
		prompt.accept();
		Thread.sleep(1000);
		driver.findElement(By.id("prompt")).click();
		Thread.sleep(1000);
		prompt = driver.switchTo().alert();

		prompt.dismiss();
		Thread.sleep(1000);
		driver.quit();

	}
}
