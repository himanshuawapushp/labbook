package com.cg.ems.ui;

import java.util.ArrayList;

import com.cg.ems.dto.Employee;
import com.cg.ems.service.EmployeeService;
import com.cg.ems.service.EmployeeServiceImp;

public class TestEmpJpaDemo {
	public static void main(String[] args)
	{
		EmployeeService empSer = new EmployeeServiceImp();
		//Employee e1 = new Employee();
		//e1.setEmpName("aaa");
		//e1.setEmpSal(8000.0F);
		//Employee e2 = new Employee(555,"Vikas Agrawal",89000.0F,null);
		//Employee ee1=empSer.addEmp(e1);
		//Employee ee2=empSer.addEmp(e2);
		//System.out.println(ee1 + "\n and " + "are inserted");
		/*Employee ee = empSer.getEmpbyEid(555);
		System.out.println(ee);
		System.out.println("Fetch all Record");
		ArrayList<Employee> eList = empSer.fetchAllEmp();
		for(Employee tempE: eList)
		{
			System.out.println(tempE.getEmpId()+"\t" + tempE.getEmpName()+"\t"+ tempE.getEmpSal());
		}*/
		//System.out.println("----------Delete------");
		//Employee deletedEmp = empSer.deleteEmp(112);
		//System.out.println(deletedEmp + "deleted");
		System.out.println("-----update-------");
		Employee updatedE=empSer.updateEmp(555, "kaushal", 90000);
		System.out.println("Update..data" + updatedE.getEmpId());

		
	}

}
