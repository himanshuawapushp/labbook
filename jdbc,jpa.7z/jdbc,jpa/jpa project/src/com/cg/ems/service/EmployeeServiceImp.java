package com.cg.ems.service;

import java.util.ArrayList;

import com.cg.ems.dao.EmployeeDao;
import com.cg.ems.dao.EmployeeDaoImpl;
import com.cg.ems.dto.Employee;

public class EmployeeServiceImp implements EmployeeService {
	EmployeeDao dao = null;
	public EmployeeServiceImp()
	{
		dao= new EmployeeDaoImpl();
	}

	@Override
	public Employee addEmp(Employee emp) {
		// TODO Auto-generated method stub
		return dao.addEmp(emp);
	}

	@Override
	public ArrayList<Employee> fetchAllEmp() {
		// TODO Auto-generated method stub
		return dao.fetchAllEmp();
	}

	@Override
	public Employee deleteEmp(int empId) {
		// TODO Auto-generated method stub
		return dao.deleteEmp(empId);
	}

	@Override
	public Employee getEmpbyEid(int empId) {
		// TODO Auto-generated method stub
		return dao.getEmpbyEid(empId);
	}

	@Override
	public Employee updateEmp(int emoId, String newName, float newSal) {
		// TODO Auto-generated method stub
		return dao.updateEmp(emoId, newName, newSal);
	}

}
