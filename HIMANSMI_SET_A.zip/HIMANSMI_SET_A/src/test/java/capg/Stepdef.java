package capg;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageBean.Registration;

public class Stepdef {
	private WebDriver driver;
	private Registration obj;

	@Given("^User is on Registration Form page$")
	public void user_is_on_Registration_Form_page() throws Throwable {

		Thread.sleep(1000);
		System.setProperty("webdriver.chrome.driver", "driver\\chromedriver.exe");
		driver = new ChromeDriver();
		Thread.sleep(1000);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		obj = new Registration(driver);
		driver.get("file:///C:/Users/HIMANSMI/Desktop/HIMANSMI_SET_A/pages/RegistrationForm.html");
	}

	@Then("^check the title of the page$")
	public void check_the_title_of_the_page() throws Throwable {
		Thread.sleep(1000);
		String title = driver.getTitle();
		if (title.contentEquals("Welcome to JobsWorld"))
			System.out.println("****** Title Not Matched");
		else
			System.out.println("****** Title  Matched");
		Thread.sleep(4000);
		driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
		driver.close();
	}

	@When("^user enters all valid data$")
	public void user_enters_all_valid_data() throws Throwable {
		obj.setUser("151500232");
		Thread.sleep(1000);
		obj.setPass("Awapushp");
		Thread.sleep(1000);
		obj.setUname("Himanshu");
		Thread.sleep(1000);
		obj.setAdd("Kushahan231304");
		Thread.sleep(1000);
		obj.setCtry("India");
		Thread.sleep(1000);
		obj.setZp("242804");
		Thread.sleep(1000);
		obj.setMail("himanshumishra536@gmail.com");
		Thread.sleep(1000);
		obj.setSexx("Male");
		Thread.sleep(1000);
		obj.setEng("English");
		Thread.sleep(1000);
		driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);

	}

	@Then("^click on submit button$")
	public void click_on_submit_button() throws Throwable {
		obj.setButton();
	}

	@When("^user leaves userid empty$")
	public void user_leaves_userid_empty() throws Throwable {
		obj.setUser("");

	}

	@When("^clicks the submit button$")
	public void clicks_the_submit_button() throws Throwable {
		obj.setButton();
	}

	@Then("^display alert msg$")
	public void display_alert_msg() throws Throwable {
		String alertmessage = driver.switchTo().alert().getText();
		System.out.println("The alert message is:" + alertmessage);
		driver.switchTo().alert().accept();
		driver.close();

	}

	@When("^user enter wrong length of user id$")
	public void user_enter_wrong_length_of_user_id() throws Throwable {
		obj.setUser("123");

	}

	@When("^user leaves password empty$")
	public void user_leaves_password_empty() throws Throwable {
		obj.setUser("151500232");
		Thread.sleep(1000);
		obj.setPass("");
	}

	@When("^user enters all data$")
	public void user_enters_all_data() throws Throwable {
		obj.setUser("151500232");
		Thread.sleep(1000);
		obj.setUname("Himanshu");
		Thread.sleep(1000);
		obj.setPass("Awap");
		obj.setAdd("Kushahan231304");
		Thread.sleep(1000);
		obj.setCtry("India");
		Thread.sleep(1000);
		obj.setZp("242804");
		Thread.sleep(1000);
		obj.setMail("himanshumishra536@gmail.com");
		Thread.sleep(1000);
		obj.setSexx("Male");
		Thread.sleep(1000);
		obj.setEng("English");
		Thread.sleep(1000);
	   

	}

	@When("^user enters wrong length of password and clicks the button$")
	public void user_enters_wrong_length_of_password_and_clicks_the_button() throws Throwable {
		obj.setPass("ol");
		Thread.sleep(1000);
		obj.setButton();
	}

	@When("^user leaves Name empty$")
	public void user_leaves_Name_empty() throws Throwable {
		obj.setUser("151500232");
		Thread.sleep(1000);
		obj.setPass("Awapushp");
		Thread.sleep(1000);
		obj.setUname("");

	}

	@When("^user enter wrong type of name$")
	public void user_enter_wrong_type_of_name() throws Throwable {
		obj.setUser("151500232");
		Thread.sleep(1000);
		obj.setPass("Awapushp");
		Thread.sleep(1000);
		obj.setUname("12345");
		Thread.sleep(1000);
	}

	@When("^user leaves Address empty$")
	public void user_leaves_Address_empty() throws Throwable {
		obj.setUser("151500232");
		Thread.sleep(1000);
		obj.setPass("Awapushp");
		Thread.sleep(1000);
		obj.setUname("Himanshu");
		Thread.sleep(1000);
		obj.setAdd("");
	}

	@When("^user enter wrong type of address$")
	public void user_enter_wrong_type_of_address() throws Throwable {
		obj.setUser("151500232");
		Thread.sleep(1000);
		obj.setPass("Awapushp");
		Thread.sleep(1000);
		obj.setUname("Himanshu");
		Thread.sleep(1000);
		obj.setAdd("k n d");
	}

	@When("^user not select any country$")
	public void user_not_select_any_country() throws Throwable {
		obj.setUser("151500232");
		Thread.sleep(1000);
		obj.setPass("Awapushp");
		Thread.sleep(1000);
		obj.setUname("Himanshu");
		Thread.sleep(1000);
		obj.setAdd("Kushahan231304");
		Thread.sleep(1000);
		obj.setCtry("(Please select a country)");

	}

	@When("^user leaves zipcode empty$")
	public void user_leaves_zipcode_empty() throws Throwable {
		obj.setUser("151500232");
		Thread.sleep(1000);
		obj.setPass("Awapushp");
		Thread.sleep(1000);
		obj.setUname("Himanshu");
		Thread.sleep(1000);
		obj.setAdd("Kushahan231304");
		Thread.sleep(1000);
		obj.setCtry("India");
		Thread.sleep(1000);
		obj.setZp("");
	}

	@When("^user enters wrong zipcode$")
	public void user_enters_wrong_zipcode() throws Throwable {
		obj.setUser("151500232");
		Thread.sleep(1000);
		obj.setPass("Awapushp");
		Thread.sleep(1000);
		obj.setUname("Himanshu");
		Thread.sleep(1000);
		obj.setAdd("Kushahan231304");
		Thread.sleep(1000);
		obj.setCtry("India");
		Thread.sleep(1000);
		obj.setZp("a b c");
	}

	@When("^user leaves email empty$")
	public void user_leaves_email_empty() throws Throwable {
		obj.setUser("151500232");
		Thread.sleep(1000);
		obj.setPass("Awapushp");
		Thread.sleep(1000);
		obj.setUname("Himanshu");
		Thread.sleep(1000);
		obj.setAdd("Kushahan Adalpura 231304");
		Thread.sleep(1000);
		obj.setCtry("India");
		Thread.sleep(1000);
		obj.setZp("242804");
		Thread.sleep(1000);
		obj.setMail("");
	}

	@When("^user enters wrong format of email id$")
	public void user_enters_wrong_format_of_email_id() throws Throwable {
		obj.setUser("151500232");
		Thread.sleep(1000);
		obj.setPass("Awapushp");
		Thread.sleep(1000);
		obj.setUname("Himanshu");
		Thread.sleep(1000);
		obj.setAdd("Kushahan231304");
		Thread.sleep(1000);
		obj.setCtry("India");
		Thread.sleep(1000);
		obj.setZp("242804");
		Thread.sleep(1000);
		obj.setMail("h@.com");
	}

	@When("^user does not select any gender$")
	public void user_does_not_select_any_gender() throws Throwable {
		obj.setUser("151500232");
		Thread.sleep(1000);
		obj.setPass("Awapushp");
		Thread.sleep(1000);
		obj.setUname("Himanshu");
		Thread.sleep(1000);
		obj.setAdd("Kushahan231304");
		Thread.sleep(1000);
		obj.setCtry("India");
		Thread.sleep(1000);
		obj.setZp("242804");
		Thread.sleep(1000);
		obj.setMail("himanshumishra536@gmail.com");
		Thread.sleep(1000);
		obj.setSexx("");
	}

	@When("^select language$")
	public void select_language() throws Throwable {
		obj.setUser("151500232");
		Thread.sleep(1000);
		obj.setPass("Awapushp");
		Thread.sleep(1000);
		obj.setUname("Himanshu");
		Thread.sleep(1000);
		obj.setAdd("Kushahan231304");
		Thread.sleep(1000);
		obj.setCtry("India");
		Thread.sleep(1000);
		obj.setZp("242804");
		Thread.sleep(1000);
		obj.setMail("himanshumishra536@gmail.com");
		Thread.sleep(1000);
		obj.setSexx("Male");
		Thread.sleep(1000);
		obj.setEng("English");
	}

	@Then("^clicks the submit buttons$")
	public void clicks_the_submit_buttons() throws Throwable {
		obj.setButton();
	}
}
