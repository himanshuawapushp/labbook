package pageBean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Registration {
	WebDriver driver;

	// step 1 : identify elements
	@FindBy(name = "userid")
	@CacheLookup
	WebElement user;

	@FindBy(name = "passid")
	@CacheLookup
	WebElement pass;

	@FindBy(name = "username")
	@CacheLookup
	WebElement uname;

	@FindBy(name = "address")
	@CacheLookup
	WebElement add;

	@FindBy(name = "country")
	@CacheLookup
	WebElement ctry;

	@FindBy(name = "zip")
	@CacheLookup
	WebElement zp;

	@FindBy(name = "email")
	@CacheLookup
	WebElement mail;

	@FindBy(name = "sex")
	@CacheLookup
	WebElement sexx;

	@FindBy(name = "en")
	@CacheLookup
	WebElement eng;

	@FindBy(name = "desc")
	@CacheLookup
	WebElement addre;

	@FindBy(name = "submit")
	@CacheLookup
	WebElement button;

	// step 2 : Setters and getter

	public WebElement getButton() {
		return button;
	}

	public void setButton() {
		button.click();
	}

	public WebElement getUser() {
		return user;
	}

	public void setUser(String usern) {
		user.sendKeys(usern);
	}

	public WebElement getPass() {
		return pass;
	}

	public void setPass(String passn) {
		pass.sendKeys(passn);

	}

	public WebElement getUname() {
		return uname;
	}

	public void setUname(String unamen) {
		uname.sendKeys(unamen);
	}

	public WebElement getAdd() {
		return add;
	}

	public void setAdd(String addn) {
		add.sendKeys(addn);
	}

	public WebElement getCtry() {
		return ctry;
	}

	public void setCtry(String ctryn) {
		ctry.sendKeys(ctryn);
	}

	public WebElement getZp() {
		return zp;
	}

	public void setZp(String zpn) {
		zp.sendKeys(zpn);
	}

	public WebElement getMail() {
		return mail;
	}

	public void setMail(String mailn) {
		mail.sendKeys(mailn);
	}

	public WebElement getSexx() {
		return sexx;
	}

	public void setSexx(String sexxn) {
		sexx.click();
	}

	public WebElement getEng() {
		return eng;
	}

	public void setEng(String engn) {
		eng.click();
	}

	public WebElement getAddre() {
		return addre;
	}

	public void setAddre(String addren) {
		addre.sendKeys(addren);
	}
	// initiating Elements

	public Registration(WebDriver driver) {

		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

}
