package com.cg.ems.ui;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import com.cg.ems.dto.Address;
import com.cg.ems.dto.Student;
import com.cg.ems.util.JPAUtil;

public class TestoneToOne {
	public static void main(String args[])
	{
		EntityManager em=JPAUtil.getentityManager();
		EntityTransaction et=em.getTransaction();
		Address vAddress=new Address();
		vAddress.setCity("Pune");
		vAddress.setState("Maharastra");
		vAddress.setStreet("Sinhagad Road");
		vAddress.setZipcode("12345");
		
		Address rAddress=new Address();
		rAddress.setCity("Mathura");
		rAddress.setState("UP");
		rAddress.setStreet(" Mg Road");
		rAddress.setZipcode("281403");
		
		Student vinita=new Student();
		vinita.setStuName("Vinita Singh");
		vinita.setStuAddress(vAddress);
		
		Student rahul=new Student();
		rahul.setStuName("vikasg agarawal");
		rahul.setStuAddress(rAddress);
		
		Address pAddress=new Address();
		pAddress.setCity("Mumbai");
		pAddress.setState("Maharastra");
		pAddress.setStreet("Singh Road");
		pAddress.setZipcode("12346");
		
		Address qAddress=new Address();
		qAddress.setCity("Agra");
		qAddress.setState("UP");
		qAddress.setStreet(" GT Road");
		qAddress.setZipcode("281406");
		
		Student sumit=new Student();
		sumit.setStuName("Sumit Chouhan");
		sumit.setStuAddress(pAddress);
		
		Student himanshu=new Student();
		himanshu.setStuName("Himanshu Mishra");
		himanshu.setStuAddress(qAddress);
		et.begin();
		em.persist(vinita);
		em.persist(rahul);
		em.persist(sumit);
		em.persist(himanshu);
		et.commit();
		System.out.println("data is inserted");
		
		
		System.out.println("..........fetch.......");
	}
}
